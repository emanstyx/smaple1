$(document).ready(function()
 {
	
	 names= [ 
					{ "uname":"admin", "pswd":"admin","status":"active" }
				];
					
		

	//Sign Up		

		$("#btnadd").click(function()
		{

			uname=document.getElementById('uname').value;
			pswd=document.getElementById('pswd').value;
			cpswd=document.getElementById('cpswd').value;
			exist = false;
			notequals=false;
			message ="";
			$("#divmsg").empty();
			for(i in names)
				{	
					if(names[i].uname == uname )
					{
						
						exist=true;
						message+="Username already exist <br>";
						break;
					}
				}

			if(pswd != cpswd)
			{
				notequals=true;

				message+="Password and Confirm Password is not equal <br>";
			}

			if(exist || notequals)
			{
				$("#divmsg").append(message);
			}
			else
		    {
		    	names.push({uname: uname,pswd:pswd, status:"active"});
		    	$("#divmsg").append("Account has been added!!");
		    }	 
			 
			 document.getElementById('uname').value="";
			 document.getElementById('pswd').value="";
			 document.getElementById('cpswd').value="";
			 
		}); 
	 
	 // login

	  $("#loginbtnlogin").click(function()
	 {
	 	$("#logindivmsg").empty();
	 	uname=document.getElementById('loginuname').value;
		pswd=document.getElementById('loginpswd').value;
		exist =false;
		
		for(i in names)
				{	
					if(names[i].uname == uname && names[i].pswd ==pswd && names[i].status =="active")
					{
						exist =true;
						break;
					}
				}
		if(exist)
		{
			if(uname =="admin")
			{
				$("#tbl").empty();
				$("#tbod").empty();
				window.location.replace("#show");

			}
			else
			{
				window.location.replace("#hello");
			}
		}
		else
		{
			$("#logindivmsg").append("Account does not exist");
		}
		document.getElementById('loginuname').value="";
		document.getElementById('loginpswd').value="";

	 });
	 
	//show the Account Status in the admin

	  $("#btnshow").click(function()
	 {
			 	
			 	stat=$("#sel1" ).val();
				$("#tbl").empty();
				$("#tbod").empty();
				$("#tbl").append("<table class= 'table center-table' id='table1'>"
										+"<thead>"
											+"<tr align='center'>"
												+"<th>Username</th>"
											+"</tr>"
										+"</thead>"
										+"<tbody id='tbod'>"
										+"</tbody>"
									+"</table>");
				for(i in names)
				{	
					if(names[i].status==stat && names[i].uname!='admin' )
					{
					$("#tbod").append ("<tr align='center'> <td>"+names[i].uname
										+"</td></tr>");
					}
				}


	 });

//deactivate account
	$("#deactbtnlogin").click(function()
	 {
	 	checker =0;
	 	$("#deactdivmsg").empty();
	 	uname=document.getElementById('deactuname').value;
		pswd=document.getElementById('deactpswd').value;
		exist =false;
		
		for(i in names)
				{	
					if(names[i].uname == uname && names[i].pswd ==pswd && names[i].status=="active")
					{
						checker =i;
						exist =true;
						break;
					}
				}
		if(exist)
		{
			names[checker].status ="deactivated";
			$("#deactdivmsg").append("Account deactivated");
		}
		else
		{
			$("#deactdivmsg").append("Account does not exist");
		}


	 });
	
//

	$("#btndeact").click(function()
	 {
        document.getElementById('deactuname').value="";
		document.getElementById('deactpswd').value="";
		$("#deactdivmsg").empty();
	 });

});
//<input type='checkbox' name='name[]' value='"+names[i].firstName+"'/>